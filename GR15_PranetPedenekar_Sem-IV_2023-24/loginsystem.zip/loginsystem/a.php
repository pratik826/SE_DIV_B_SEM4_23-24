<!DOCTYPE html> 
<html> 
<head> 
    <title> Mark Attendance </title> 
    <!-- Include your CSS stylesheets or Bootstrap CDN links here -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
</head> 
<body> 
    <!-- Include your JavaScript scripts or Bootstrap CDN links here -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</body> 
</html> 
















<?php
session_start();
require 'partials/_nav.php';
require 'partials/_dbconnect.php';

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['approve'])) {
        // Handle approval of leave
        $leaveId = $_POST['leave_id'];

        // Update leave status to 'approved' in the leaves table
        $updateSql = "UPDATE leaves SET status = 'approved' WHERE leave_id = '$leaveId'";
        $updateResult = mysqli_query($conn, $updateSql);

        if ($updateResult) {
            // Retrieve leave dates for the approved leave
            $leaveDatesSql = "SELECT leave_start_date, leave_end_date, emp_id FROM leaves WHERE leave_id = '$leaveId'";
            $leaveDatesResult = mysqli_query($conn, $leaveDatesSql);
            $row = mysqli_fetch_assoc($leaveDatesResult);
            $startDate = $row['leave_start_date'];
            $endDate = $row['leave_end_date'];
            $empId = $row['emp_id'];

            // Insert attendance records for the approved leave period
            $insertAttendanceSql = "INSERT INTO attendance (emp_id, date, status) VALUES ";
            $dates = array();
            $currentDate = strtotime($startDate);
            while ($currentDate <= strtotime($endDate)) {
                $dates[] = date("Y-m-d", $currentDate);
                $currentDate = strtotime("+1 day", $currentDate);
            }
            foreach ($dates as $date) {
                $insertAttendanceSql .= "('$empId', '$date', 'On Leave'),";
            }
            // Remove the trailing comma
            $insertAttendanceSql = rtrim($insertAttendanceSql, ',');
            
            $insertAttendanceResult = mysqli_query($conn, $insertAttendanceSql);

            if (!$insertAttendanceResult) {
                echo "Error inserting attendance records: " . mysqli_error($conn);
            }

            echo "Leave approved successfully!";
        } else {
            echo "Error approving leave: " . mysqli_error($conn);
        }
    } elseif (isset($_POST['reject'])) {
        // Handle rejection of leave
        $leaveId = $_POST['leave_id'];

        // Update leave status to 'rejected' in the leaves table
        $updateSql = "UPDATE leaves SET status = 'rejected' WHERE leave_id = '$leaveId'";
        $updateResult = mysqli_query($conn, $updateSql);

        if ($updateResult) {
            // Retrieve leave dates for the rejected leave
            $leaveDatesSql = "SELECT leave_start_date, leave_end_date, emp_id FROM leaves WHERE leave_id = '$leaveId'";
            $leaveDatesResult = mysqli_query($conn, $leaveDatesSql);
            $row = mysqli_fetch_assoc($leaveDatesResult);
            $startDate = $row['leave_start_date'];
            $endDate = $row['leave_end_date'];
            $empId = $row['emp_id'];

            // Remove attendance records for the rejected leave period
            $deleteAttendanceSql = "DELETE FROM attendance WHERE emp_id = '$empId' AND date BETWEEN '$startDate' AND '$endDate'";
            $deleteAttendanceResult = mysqli_query($conn, $deleteAttendanceSql);

            if (!$deleteAttendanceResult) {
                echo "Error deleting attendance records: " . mysqli_error($conn);
            }

            echo "Leave rejected successfully!";
        } else {
            echo "Error rejecting leave: " . mysqli_error($conn);
        }
    }
}

// Retrieve leaves data from the database with employee names
$sql = "SELECT leaves.*, CONCAT(employees.first_name, ' ', employees.last_name) AS full_name
        FROM leaves 
        JOIN employees ON leaves.emp_id = employees.emp_id";
$result = mysqli_query($conn, $sql);
?> 


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Leaves</title>
    <!-- Include Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <!-- Custom CSS for container width -->
    <style>
        .custom-container {
            max-width: 90%; /* Adjust the percentage as needed */
            margin: auto; /* Center the container horizontally */
        }
    </style>
</head>
<body>
    <div  class="container mt-4 custom-container">
        <h2>Manage Leaves</h2>
        <table class="table">
            <thead>
                <tr>
                    <th>Leave ID</th>
                    <th>Date of Application</th>
                    <th>Employee Name</th>
                    <th>Leave Subject</th>
                    <th>Leave Start Date</th>
                    <th>Leave End Date</th>
                    <th>Leave Type</th>
                    <th>Leave Message</th>
                    <th>Status</th> <!-- New column for status -->
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Loop through each row of leaves data
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>";
                    echo "<td>" . $row['leave_id'] . "</td>";
                    echo "<td>" . $row['applied_at'] . "</td>";
                    echo "<td>" . $row['full_name'] . "</td>"; // Display employee full name
                    echo "<td>" . $row['leave_subject'] . "</td>";
                    echo "<td>" . $row['leave_start_date'] . "</td>";
                    echo "<td>" . $row['leave_end_date'] . "</td>";
                    echo "<td>" . $row['leave_type'] . "</td>";
                    echo "<td>" . $row['leave_message'] . "</td>";
                    echo "<td>" . $row['status'] . "</td>"; //Display status
                    // Action buttons for accepting and rejecting leaves
                    echo "<td>
                            <form action='' method='post'>
                                <input type='hidden' name='leave_id' value='" . $row['leave_id'] . "'>
                                <button type='submit' class='btn btn-success' name='approve'>Approve</button>
                                <button type='submit' class='btn btn-danger' name='reject'>Reject</button>
                            </form>
                            <a href='view_leave.php?leave_id=" . $row['leave_id'] . "' class='btn btn-primary'>View</a>
                          </td>";
                    echo "</tr>";
                }
                ?>
            </tbody>
        </table>
    </div>

    <!-- Include Bootstrap JS (if needed) -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</body>
</html>






























<?php
$showAlert = false;
$showError = false;
if($_SERVER["REQUEST_METHOD"] == "POST"){
    include 'partials/_dbconnect.php';
    $username = $_POST["username"];
    $password = $_POST["password"];
    $cpassword = $_POST["cpassword"];
    $isadmin = isset($_POST["is_admin"]) ? 1 : 0; // If checked, set to 1, else set to 0
    //var_dump($isadmin);
    // $exists=false;

    // Check whether this username exists
    $existSql = "SELECT * FROM `Employees` WHERE username = '$username'";
    $result = mysqli_query($conn, $existSql);
    $numExistRows = mysqli_num_rows($result);
    if($numExistRows > 0){
        // $exists = true;
        $showError = "Username Already Exists";
    }
    else{
        // $exists = false; 
        if(($password == $cpassword)){
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $sql = "INSERT INTO `Employees` ( `username`, `password` , `is_admin`) VALUES ('$username', '$password' , '$isadmin')";
            $result = mysqli_query($conn, $sql);
            if ($result){
                $showAlert = true;
            }
        }
        else{
            $showError = "Passwords do not match";
        }
    }
}
    
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <title>SignUp</title>
  </head>
  <body>
    <?php require 'partials/_nav.php' ?>
    <?php
    if($showAlert){
    echo ' <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Success!</strong> Your account is now created and you can login
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div> ';
    }
    if($showError){
    echo ' <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <strong>Error!</strong> '. $showError.'
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div> ';
    }
    ?>

    <div class="container my-4">
     <h1 class="text-center">Signup to our website</h1>
     <form action="/Project/loginsystem/signup.php" method="post">
        <div class="form-group">
            <label for="username">Username</label>
            <input type="text" maxlength="11" class="form-control" id="username" name="username" aria-describedby="emailHelp">
            
        </div>
        <div class="form-group">
            <label for="password">Password</label>
            <input type="password" maxlength="23" class="form-control" id="password" name="password">
        </div>
        <div class="form-group">
            <label for="cpassword">Confirm Password</label>
            <input type="password" class="form-control" id="cpassword" name="cpassword">
            <small id="emailHelp" class="form-text text-muted">Make sure to type the same password</small>
        </div>
       <!-- <div class="form-check">
            <input type="checkbox" class="form-check-input" id="is_admin" name="is_admin">
            <label class="form-check-label" for="is_admin">Admin</label>
        </div>   -->
         
        <button type="submit" class="btn btn-primary">SignUp</button>
     </form>  
    </div>   

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
  </body>
</html>


