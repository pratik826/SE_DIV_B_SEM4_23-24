<?php
session_start();
require 'partials/_nav.php';
require 'partials/_dbconnect.php';

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Handle form submission
    // Retrieve form data
    $empId = isset($_SESSION['emp_id']) ? $_SESSION['emp_id'] : ''; // Check if $_SESSION['emp_id'] is set
    $leaveSubject = isset($_POST['leave_subject']) ? mysqli_real_escape_string($conn, $_POST['leave_subject']) : '';
    $leaveStartDate = isset($_POST['leave_start_date']) ? mysqli_real_escape_string($conn, $_POST['leave_start_date']) : '';
    $leaveEndDate = isset($_POST['leave_end_date']) ? mysqli_real_escape_string($conn, $_POST['leave_end_date']) : '';
    $leaveType = isset($_POST['leave_type']) ? mysqli_real_escape_string($conn, $_POST['leave_type']) : '';
    $leaveMessage = isset($_POST['leave_message']) ? mysqli_real_escape_string($conn, $_POST['leave_message']) : '';

    // Insert data into the leaves table
    $sql = "INSERT INTO leaves (emp_id, leave_subject, leave_start_date, leave_end_date, leave_type, leave_message) 
            VALUES ('$empId', '$leaveSubject', '$leaveStartDate', '$leaveEndDate', '$leaveType', '$leaveMessage')";
    $result = mysqli_query($conn, $sql);

    if ($result) {
        echo "Leave application submitted successfully!";
    } else {
        echo "Error: " . mysqli_error($conn);
        // Handle error as needed
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Apply for Leave</title>
    <!-- Include Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
</head>
<body>

    <div class="container mt-4">
        <h2>Apply for Leave</h2>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
            <div class="form-group">
                <label for="leave_subject">Leave Subject:</label>
                <input type="text" id="leave_subject" name="leave_subject" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="leave_start_date">Leave Start Date:</label>
                <input type="date" id="leave_start_date" name="leave_start_date" class="form-control" required min="<?php echo date('Y-m-d'); ?>">
            </div>
            <div class="form-group">
                <label for="leave_end_date">Leave End Date:</label>
                <input type="date" id="leave_end_date" name="leave_end_date" class="form-control" required min="<?php echo date('Y-m-d'); ?>">
            </div>

            <div class="form-group">
                <label for="leave_type">Leave Type:</label>
                <select id="leave_type" name="leave_type" class="form-control" required>
                    <option value="">Select Leave Type</option>
                    <option value="Sick Leave">Sick Leave</option>
                    <option value="Vacation Leave">Vacation Leave</option>
                    <option value="Personal Leave">Personal Leave</option>
                    <option value="Personal Leave">Casual Leave</option>
                    <option value="Personal Leave">Medical/Sick Leave</option>
                    <option value="Personal Leave">Privileged/Earned Leave</option>
                    <option value="Personal Leave">Maternity Leave</option>
                </select>
            </div>
            <div class="form-group">
                <label for="leave_message">Leave Message:</label>
                <textarea id="leave_message" name="leave_message" class="form-control" rows="5" required></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>

    <!-- Include Bootstrap JS (if needed) -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</body>
</html> 

