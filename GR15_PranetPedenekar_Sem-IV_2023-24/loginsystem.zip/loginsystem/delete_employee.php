<?php
session_start();
require 'partials/_nav.php';
require 'partials/_dbconnect.php'; // Include your database connection script

// Delete employee record if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['emp_id'])) {
    $emp_id = $_POST['emp_id'];

    // Delete employee record from the database
    $sql = "DELETE FROM Employees WHERE emp_id = '$emp_id'";
    $result = mysqli_query($conn, $sql);

    if ($result) {
        // Redirect to success page or display success message
        echo "Employee deleted successfully.";
        // Add any additional logic here, such as redirecting to another page
    } else {
        // Redirect to error page or display error message
        echo "Error deleting employee.";
        // Add any additional logic here, such as redirecting to an error page
    }
}

// Fetch non-admin employee data
$sql = "SELECT emp_id, CONCAT(first_name, ' ', last_name) AS full_name, department, designation FROM Employees WHERE is_admin = 0";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Employee</title>
    <!-- Include Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-4">
        <h2>Delete Employees</h2>
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Employee ID</th>
                        <th>Full Name</th>
                        <th>Department</th>
                        <th>Designation</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = mysqli_fetch_assoc($result)) { ?> 
                        <tr> 
                            <td><?php echo $row['emp_id']; ?></td> 
                            <td><?php echo $row['full_name']; ?></td> 
                            <td><?php echo $row['department']; ?></td> 
                            <td><?php echo $row['designation']; ?></td>
                            <td>
                                <!-- Delete button -->
                                <form action="" method="POST">
                                    <input type="hidden" name="emp_id" value="<?php echo $row['emp_id']; ?>">
                                    <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this employee?')">Delete</button>
                                </form>
                            </td> 
                        </tr> 
                    <?php } ?> 
                </tbody>
            </table>
        </div>
    </div>

    <!-- Include Bootstrap JS (if needed) -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</body>
</html>
