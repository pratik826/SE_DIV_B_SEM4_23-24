<?php
session_start();
require 'partials/_nav.php'; // Include your navigation menu
require 'partials/_dbconnect.php'; // Include your database connection script

if (isset($_GET['id'])) {
    $emp_id = $_GET['id'];

    // Fetch employee details
    $sql = "SELECT * FROM Employees WHERE emp_id = '$emp_id'";
    $result = mysqli_query($conn, $sql);
    $employeeData = mysqli_fetch_assoc($result);

    $department = $employeeData['department'];
    $designation = $employeeData['designation'];
    $basic_salary = $employeeData['basic_salary'];
    $tax_rate = $employeeData['tax_rate'];
    $pf_rate = $employeeData['pf_rate'];
    $ha_rate = $employeeData['ha_rate'];
    $first_name = $employeeData['first_name'];
    $last_name = $employeeData['last_name'];
} else {
    echo "Employee ID not provided.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Employee</title>
    <!-- Include Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-4">
        <h2>Edit Details of  <?php echo $first_name . ' ' . $last_name; ?></h2>
        <form action="update_employee.php" method="POST">
            <div class="form-group">
                <label for="emp_id">Employee Id:</label>
                <input type="text" class="form-control" id="emp_id" name="emp_id" value="<?php echo $emp_id; ?>" readonly>
            </div>
            <div class="form-group">
                <label for="department">Department:</label>
                <input type="text" class="form-control" id="department" name="department" value="<?php echo $department; ?>">
            </div>
            <div class="form-group">
                <label for="designation">Designation:</label>
                <input type="text" class="form-control" id="designation" name="designation" value="<?php echo $designation; ?>">
            </div>
            <div class="form-group">
                <label for="basic_salary">Basic Salary:</label>
                <input type="text" class="form-control" id="basic_salary" name="basic_salary" value="<?php echo $basic_salary; ?>">
            </div>
            <div class="form-group">
                <label for="pf_rate">PF Rate:</label>
                <input type="text" class="form-control" id="pf_rate" name="pf_rate" value="<?php echo $pf_rate; ?>">
            </div>
            <div class="form-group">
                <label for="tax_rate">Tax Rate:</label>
                <input type="text" class="form-control" id="tax_rate" name="tax_rate" value="<?php echo $tax_rate; ?>">
            </div>
            <div class="form-group">
                <label for="ha_rate">Housing Allowance Rate:</label>
                <input type="text" class="form-control" id="ha_rate" name="ha_rate" value="<?php echo $ha_rate; ?>">
            </div>
           
            <button type="submit" class="btn btn-primary">Update</button>
        </form>
    </div>

    <!-- Include Bootstrap JS (if needed) -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</body>
</html>
