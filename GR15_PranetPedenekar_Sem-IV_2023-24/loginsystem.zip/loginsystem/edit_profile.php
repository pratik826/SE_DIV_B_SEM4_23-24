<?php
session_start();
require 'partials/_dbconnect.php'; // Include your database connection script

// Fetch user data from the session
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    // Redirect the user to the login page if not logged in
    header("Location: login.php");
    exit;
}

$emp_id = $_SESSION['emp_id'];
$sql = "SELECT * FROM Employees WHERE emp_id = '$emp_id'";
$result = mysqli_query($conn, $sql);

// Check if user data was fetched successfully
if ($result && mysqli_num_rows($result) > 0) {
    // User data exists, fetch the data row
    $userData = mysqli_fetch_assoc($result);
} else {
    // User data not found, handle error (e.g., redirect to an error page)
    // For simplicity, let's redirect to the home page
    header("Location: index.php");
    exit;
}

// Handle form submission to update profile
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $firstName = $_POST["first_name"];
    $lastName = $_POST["last_name"];
    $email = $_POST["email"];
    $gender = $_POST["gender"];
    $department = $_POST["department"];
    $designation = $_POST["designation"];
    $dob = $_POST["dob"];
    $phoneNumber = $_POST["phone_number"];
    $bankName = $_POST["bank_name"];
    $bankAccountNumber = $_POST["bank_account"];
    $ifscCode = $_POST["ifsc_code"];
    $panNumber = $_POST["pan_number"];

    // Update user's profile in the database
    $updateSql = "UPDATE Employees SET first_name = '$firstName', last_name = '$lastName', email = '$email', gender = '$gender', department = '$department', designation = '$designation' , dob = '$dob', phone_number = '$phoneNumber', bank_name = '$bankName', bank_account = '$bankAccountNumber', ifsc_code = '$ifscCode', pan_number = '$panNumber' WHERE emp_id = '$emp_id'";
    $updateResult = mysqli_query($conn, $updateSql);

    if ($updateResult) {
        // Profile updated successfully, redirect to the profile page
        header("Location: profile.php");
        exit;
    } else {
        // Error updating profile, handle as needed
        $errorMessage = "Error updating profile: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile</title>
    <!-- Include your CSS stylesheets or Bootstrap CDN links here -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
</head>

<body>
    <?php require 'partials/_nav.php'; // Include your navigation menu ?>

    <div class="container">
        <h2>Edit Profile</h2>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="form-group">
                <label for="first_name">First Name:</label>
                <input type="text" class="form-control" id="first_name" name="first_name" value="<?php echo $userData['first_name']; ?>">
            </div>
            <div class="form-group">
                <label for="last_name">Last Name:</label>
                <input type="text" class="form-control" id="last_name" name="last_name" value="<?php echo $userData['last_name']; ?>">
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" class="form-control" id="email" name="email" value="<?php echo $userData['email']; ?>">
            </div>
            <div class="form-group">
                <label for="gender">Gender:</label>
                <select class="form-control" id="gender" name="gender">
                    <option value="male" <?php if ($userData['gender'] == 'male') echo 'selected'; ?>>Male</option>
                    <option value="female" <?php if ($userData['gender'] == 'female') echo 'selected'; ?>>Female</option>
                    <option value="other" <?php if ($userData['gender'] == 'other') echo 'selected'; ?>>Other</option>
                </select>
            </div>
            <div class="form-group">
                <label for="department">Department:</label>
                <select class="form-control" id="department" name="department">
                    <option value="">Select Department</option>
                    <option value="Sales and Marketing" <?php if ($userData['department'] == 'Sales and Marketing') echo 'selected'; ?>>Sales and Marketing</option>
                    <option value="IT" <?php if ($userData['department'] == 'IT') echo 'selected'; ?>>IT</option>
                    <option value="Finance" <?php if ($userData['department'] == 'Finance') echo 'selected'; ?>>Finance</option>
                    <option value="Design" <?php if ($userData['department'] == 'Design') echo 'selected'; ?>>Design</option>
                </select>
            </div>
            <div class="form-group">
                <label for="designation">Designation:</label>
                <input type="designation" class="form-control" id="designation" name="designation" value="<?php echo $userData['designation']; ?>">
            </div>
            <div class="form-group">
                <label for="dob">Date of Birth:</label>
                <input type="date" class="form-control" id="dob" name="dob" value="<?php echo $userData['dob']; ?>" max="<?php echo date('Y-m-d'); ?>">
            </div>

            <div class="form-group">
                <label for="phone_number">Phone Number:</label>
                <input type="text" class="form-control" id="phone_number" name="phone_number" value="<?php echo $userData['phone_number']; ?>">
            </div>
            <div class="form-group">
                <label for="bank_name">Bank Name:</label>
                <input type="text" class="form-control" id="bank_name" name="bank_name" value="<?php echo $userData['bank_name']; ?>">
            </div>
            <div class="form-group">
                <label for="bank_account">Bank Account Number:</label>
                <input type="text" class="form-control" id="bank_account" name="bank_account" value="<?php echo $userData['bank_account']; ?>">
            </div>
            <div class="form-group">
                <label for="ifsc_code">IFSC Code:</label>
                <input type="text" class="form-control" id="ifsc_code" name="ifsc_code" value="<?php echo $userData['ifsc_code']; ?>">
            </div>
            <div class="form-group">
                <label for="pan_number">PAN Number:</label>
                <input type="text" class="form-control" id="pan_number" name="pan_number" value="<?php echo $userData['pan_number']; ?>">
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
        <?php if (isset($errorMessage)) : ?>
            <div class="alert alert-danger mt-3" role="alert">
                <?php echo $errorMessage; ?>
            </div>
        <?php endif; ?>
    </div>

    <!-- Include your JavaScript scripts or Bootstrap CDN links here -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</body>

</html>
