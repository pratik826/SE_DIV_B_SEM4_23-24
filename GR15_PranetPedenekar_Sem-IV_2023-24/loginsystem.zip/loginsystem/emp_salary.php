<?php
session_start();
require 'partials/_nav.php';
require 'partials/_dbconnect.php';

// Check if the user is logged in
if (!isset($_SESSION['emp_id'])) {
    // Redirect to login page if not logged in
    header("Location: login.php");
    exit();
}

// Get logged-in employee ID
$emp_id = $_SESSION['emp_id'];

// Query to fetch all salary slips for the logged-in employee in descending order of submitted timestamp
$sql = "SELECT * FROM salary WHERE emp_id = $emp_id ORDER BY submitted_at DESC";
$result = mysqli_query($conn, $sql);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Salary Slips</title>
    <!-- Include Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
</head>

<body>
    <div class="container">
        <h2 class="my-4">Your Salary Slips</h2>
        <table class="table">
            <thead>
                <tr>
                    <th>Slip ID</th>
                    <th>Month</th>
                    <th>Year</th>
                    <th>Submitted At</th>
                    <th>Action</th> <!-- New column for View button -->
                </tr>
            </thead>
            <tbody>
                <?php
                // Check if there are salary slips for the logged-in employee
                if (mysqli_num_rows($result) > 0) {
                    // Fetch and display each salary slip
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<tr>";
                        echo "<td>" . $row['salary_id'] . "</td>";
                        echo "<td>" . $row['month'] . "</td>";
                        echo "<td>" . $row['year'] . "</td>";
                        echo "<td>" . $row['submitted_at'] . "</td>";
                        echo "<td><a href='view_salary_slip.php?salary_id=" . $row['salary_id'] . "&emp_id=" . $emp_id . "&month=" . $row['month'] . "&year=" . $row['year'] . "' class='btn btn-primary'>View</a></td>"; // View button
                        echo "</tr>";
                    }
                } else {
                    // No salary slips found for the logged-in employee
                    echo "<tr><td colspan='6'>No salary slips found.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>

    <!-- Include Bootstrap JS (if needed) -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</body>

</html>
