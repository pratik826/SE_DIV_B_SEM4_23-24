<?php
// Include the FPDF library
require('fpdf.php');

// Assign POST variables to local variables
$emp_id = $_POST['emp_id'];
$month = $_POST['month'];
$year = $_POST['year'];
$first_name = $_POST['first_name'];
$last_name = $_POST['last_name'];
$department = $_POST['department'];
$designation = $_POST['designation'];
$phone_number = $_POST['phone_number'];
$bank_name = $_POST['bank_name'];
$bank_account = $_POST['bank_account'];
$ifsc_code = $_POST['ifsc_code'];
$pan_number = $_POST['pan_number'];
$presentCount = $_POST['presentCount'];
$absentCount = $_POST['absentCount'];
$leaveCount = $_POST['leaveCount'];
$basic_salary = $_POST['basic_salary'];
$ha_amount = $_POST['ha_amount'];
$earnings = $_POST['earnings'];
$tax_amt = $_POST['tax_amt'];
$pf_amt = $_POST['pf_amt'];
$absence_deduction = $_POST['absence_deduction'];
$total_deductions = $_POST['total_deductions'];
$net_salary = $_POST['net_salary'];


// Create a new FPDF instance
$pdf = new FPDF();
$pdf->AddPage();

// Format the selected month and year
$selectedMonthName = date("F", mktime(0, 0, 0, $month, 1));
$selectedYear = $year;

// Salary Slip Heading
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(0, 10, 'Salary Slip for ' . $selectedMonthName . ' ' . $selectedYear, 0, 1, 'C'); // Centered
$pdf->Ln(10);


// Employee Details
$pdf->SetFont('Arial', '', 9);
$pdf->Cell(30, 10, 'Employee ID:', 0, 0);
$pdf->Cell(50, 10, $emp_id, 0, 0);
$pdf->Cell(30, 10, 'Bank Name:', 0, 0);
$pdf->Cell(50, 10, $bank_name, 0, 1);
$pdf->Cell(30, 10, 'Full Name:', 0, 0);
$pdf->Cell(50, 10, $first_name . ' ' . $last_name, 0, 0);
$pdf->Cell(30, 10, 'Bank Account:', 0, 0);
$pdf->Cell(50, 10, $bank_account, 0, 1);
$pdf->Cell(30, 10, 'Department:', 0, 0);
$pdf->Cell(50, 10, $department, 0, 0);
$pdf->Cell(30, 10, 'IFSC Code:', 0, 0);
$pdf->Cell(50, 10, $ifsc_code, 0, 1);
$pdf->Cell(30, 10, 'Designation:', 0, 0);
$pdf->Cell(50, 10, $designation, 0, 0);
$pdf->Cell(30, 10, 'Present Days:', 0, 0);
$pdf->Cell(50, 10, $presentCount, 0, 1);
$pdf->Cell(30, 10, 'Phone Number:', 0, 0);
$pdf->Cell(50, 10, $phone_number, 0, 0);
$pdf->Cell(30, 10, 'Absent Days:', 0, 0);
$pdf->Cell(50, 10, $absentCount, 0, 1);
$pdf->Cell(30, 10, 'PAN Number:', 0, 0);
$pdf->Cell(50, 10, $pan_number, 0, 0);
$pdf->Cell(30, 10, 'Leaves:', 0, 0);
$pdf->Cell(50, 10, $leaveCount, 0, 1);
$pdf->Ln();

// Earnings and Deductions Table
$pdf->Cell(90, 10, 'Earnings', 1, 0, 'C');
$pdf->Cell(90, 10, 'Deductions', 1, 1, 'C');
$pdf->Cell(45, 10, 'Particulars', 1, 0, 'C');
$pdf->Cell(45, 10, 'Amount(INR)', 1, 0, 'C');
$pdf->Cell(45, 10, 'Particulars', 1, 0, 'C');
$pdf->Cell(45, 10, 'Amount(INR)', 1, 1, 'C');

$pdf->Cell(45, 10, 'Basic Salary', 1, 0,'C');
$pdf->Cell(45, 10, $basic_salary, 1, 0, 'R'); // Align amount to the right
$pdf->Cell(45, 10, 'Tax Amount', 1, 0,'C');
$pdf->Cell(45, 10, $tax_amt, 1, 1, 'R'); // Align amount to the right

$pdf->Cell(45, 10, 'Housing Allowance', 1, 0,'C');
$pdf->Cell(45, 10, $ha_amount, 1, 0, 'R'); // Align amount to the right
$pdf->Cell(45, 10, 'PF Amount', 1, 0,'C');
$pdf->Cell(45, 10, $pf_amt, 1, 1, 'R'); // Align amount to the right

$pdf->Cell(45, 10, '', 1, 0); // Empty cell for remaining earnings particulars
$pdf->Cell(45, 10, '', 1, 0); // Empty cell for remaining earnings amounts
$pdf->Cell(45, 10, 'Absence Deduction', 1, 0,'C');
$pdf->Cell(45, 10, $absence_deduction, 1, 1, 'R'); // Align amount to the right

$pdf->SetFont('Arial', 'B', 9);
// Print total earnings
$pdf->Cell(45, 10, 'Total Earnings:', 1, 0, 'C');
$pdf->Cell(45, 10, $earnings, 1, 0, 'R'); // Align amount to the right

// Print total deductions
$pdf->Cell(45, 10, 'Total Deductions:', 1, 0, 'C');
$pdf->Cell(45, 10, $total_deductions, 1, 1, 'R'); // Align amount to the right

$pdf->Cell(90, 10, 'Net Salary:', 'LB', 0, 'C');
$pdf->Cell(90, 10, $net_salary, 'RB', 1, 'R'); // Align amount to the right

$pdf->SetFont('Arial', '', 9);
$pdf->Cell(30, 10, 'Total Net Pay for the month is  INR.', 0, 0);

$pdf->SetFont('Arial', 'B', 9);
$pdf->Cell(35, 10, $net_salary, 0, 0, 'R'); 

$pdf->Ln();
// Output the PDF as a file named salary_slip.pdf
$pdf->Output('salary_slip.pdf', 'D');
?>
