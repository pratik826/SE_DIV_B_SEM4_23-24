<?php
// Include your database connection script
require 'partials/_dbconnect.php';
require 'partials/_nav.php';

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $emp_id = $_POST['emp_id'];
    $month = $_POST['month'];
    $year = $_POST['year'];
    $housing_allowance = $_POST['housing_allowance'];
    $tax_amount = $_POST['tax_amount'];
    $pf_amount = $_POST['pf_amount'];
    $absence_deduction = $_POST['absence_deduction'];
    $earnings = $_POST['earnings'];
    $total_deduction = $_POST['total_deduction'];
    $net_salary = $_POST['net_salary'];

    // Prepare and execute SQL statement to insert data into the salary table
    $sql = "INSERT INTO salary (emp_id, ha_amount, tax_amt, pf_amt, absence_deduction, earnings, total_deductions, net_salary, month, year) 
            VALUES ('$emp_id', '$housing_allowance', '$tax_amount', '$pf_amount', '$absence_deduction', '$earnings', '$total_deduction', '$net_salary', '$month', '$year')";

    if (mysqli_query($conn, $sql)) {
        // Data inserted successfully
        echo "Salary details inserted successfully.";

        
    } else {
        // Error inserting data
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
} else {
    // If the form is not submitted, redirect to an error page or homepage
    header("Location: index.php");
    exit;
}

// Close database connection
mysqli_close($conn);
?>
<!DOCTYPE html> 
<html> 
<head> 
    <title> Mark Attendance </title> 
    <!-- Include your CSS stylesheets or Bootstrap CDN links here -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
</head> 
<body> 
    <!-- Include your JavaScript scripts or Bootstrap CDN links here -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>    
</body> 
</html> 