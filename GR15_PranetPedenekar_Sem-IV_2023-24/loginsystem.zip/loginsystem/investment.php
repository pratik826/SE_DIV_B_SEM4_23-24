<?php
session_start();
require 'partials/_nav.php';
require 'partials/_dbconnect.php'; // Include your database connection script

// Fetch the employee's net salary from the database
$emp_id = $_SESSION['emp_id']; // Assuming you have stored the employee's ID in the session

// Query to fetch the net salary based on the employee's ID
$sql = "SELECT net_salary FROM Salary WHERE emp_id = '$emp_id'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    $netSalary = $row['net_salary']; // Assign the fetched net salary to the variable
} else {
    $netSalary = 0; // Set a default value if the net salary is not found
}

// Investment suggestion based on net salary ranges
if ($netSalary < 50000) {
    $suggestion = "Consider building an emergency fund and paying off any high-interest debts.";
} elseif ($netSalary >= 50000 && $netSalary < 100000) {
    $suggestion = "Consider contributing to a retirement account like a 401(k) and opening an IRA for additional savings.";
} else {
    $suggestion = "Maximize contributions to retirement accounts, diversify investments, and explore opportunities in stocks, bonds, and real estate.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Investment Suggestion</title>
    <!-- Include Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-4">
        <h2>Investment Suggestion</h2>
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Based on your net salary of INR <?php echo $netSalary; ?>:</h5>
                <p class="card-text"><?php echo $suggestion; ?></p>
            </div>
        </div>
    </div>

    <!-- Include Bootstrap JS (if needed) -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</body>
</html>
