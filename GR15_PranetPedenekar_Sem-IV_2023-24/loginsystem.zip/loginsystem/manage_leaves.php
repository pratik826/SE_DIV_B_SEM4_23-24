<?php
session_start();
require 'partials/_nav.php';
require 'partials/_dbconnect.php';

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['approve'])) {
        // Handle approval of leave
        $leaveId = $_POST['leave_id'];

        // Update leave status to 'approved' in the leaves table
        $updateSql = "UPDATE leaves SET status = 'approved' WHERE leave_id = '$leaveId'";
        $updateResult = mysqli_query($conn, $updateSql);

        if ($updateResult) {
            // Retrieve leave dates for the approved leave
            $leaveDatesSql = "SELECT leave_start_date, leave_end_date, emp_id FROM leaves WHERE leave_id = '$leaveId'";
            $leaveDatesResult = mysqli_query($conn, $leaveDatesSql);
            $row = mysqli_fetch_assoc($leaveDatesResult);
            $startDate = $row['leave_start_date'];
            $endDate = $row['leave_end_date'];
            $empId = $row['emp_id'];

            // Insert attendance records for the approved leave period
            $insertAttendanceSql = "INSERT INTO attendance (emp_id, date, status) VALUES ";
            $dates = array();
            $currentDate = strtotime($startDate);
            while ($currentDate <= strtotime($endDate)) {
                $dates[] = date("Y-m-d", $currentDate);
                $currentDate = strtotime("+1 day", $currentDate);
            }
            foreach ($dates as $date) {
                $insertAttendanceSql .= "('$empId', '$date', 'On Leave'),";
            }
            // Remove the trailing comma
            $insertAttendanceSql = rtrim($insertAttendanceSql, ',');
            
            $insertAttendanceResult = mysqli_query($conn, $insertAttendanceSql);

            if (!$insertAttendanceResult) {
                echo "Error inserting attendance records: " . mysqli_error($conn);
            }

            echo "Leave approved successfully!";
        } else {
            echo "Error approving leave: " . mysqli_error($conn);
        }
    } elseif (isset($_POST['reject'])) {
        // Handle rejection of leave
        $leaveId = $_POST['leave_id'];

        // Update leave status to 'rejected' in the leaves table
        $updateSql = "UPDATE leaves SET status = 'rejected' WHERE leave_id = '$leaveId'";
        $updateResult = mysqli_query($conn, $updateSql);

        if ($updateResult) {
            // Retrieve leave dates for the rejected leave
            $leaveDatesSql = "SELECT leave_start_date, leave_end_date, emp_id FROM leaves WHERE leave_id = '$leaveId'";
            $leaveDatesResult = mysqli_query($conn, $leaveDatesSql);
            $row = mysqli_fetch_assoc($leaveDatesResult);
            $startDate = $row['leave_start_date'];
            $endDate = $row['leave_end_date'];
            $empId = $row['emp_id'];

            // Remove attendance records for the rejected leave period
            $deleteAttendanceSql = "DELETE FROM attendance WHERE emp_id = '$empId' AND date BETWEEN '$startDate' AND '$endDate'";
            $deleteAttendanceResult = mysqli_query($conn, $deleteAttendanceSql);

            if (!$deleteAttendanceResult) {
                echo "Error deleting attendance records: " . mysqli_error($conn);
            }

            echo "Leave rejected successfully!";
        } else {
            echo "Error rejecting leave: " . mysqli_error($conn);
        }
    }
}

// Retrieve leaves data from the database with employee names
$sql = "SELECT leaves.*, CONCAT(employees.first_name, ' ', employees.last_name) AS full_name
        FROM leaves 
        JOIN employees ON leaves.emp_id = employees.emp_id
        ORDER BY leaves.applied_at DESC";

$result = mysqli_query($conn, $sql);
?> 


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Leaves</title>
    <!-- Include Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <!-- Custom CSS for container width -->
    <style>
        .custom-container {
            max-width: 90%; /* Adjust the percentage as needed */
            margin: auto; /* Center the container horizontally */
        }
        .btn-group {
            display: flex;
        }
        .btn-group .btn {
            margin-right: 5px;
            height: 33px; /* Set the height of buttons */
            line-height: 17px; /* Center the button content vertically */
        }
    </style>
</head>
<body>
    <div>
        <h2>Manage Leaves</h2>
        <table class="table">
            <thead>
                <tr>
                    <th>Leave ID</th>
                    <th>Date of Application</th>
                    <th>Employee Name</th>
                    <th>Leave Subject</th>
                    <th>Leave Start Date</th>
                    <th>Leave End Date</th>
                    <th>Leave Type</th>
                    <th>Leave Message</th>
                    <th>Status</th> <!-- New column for status -->
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Loop through each row of leaves data
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>";
                    echo "<td>" . $row['leave_id'] . "</td>";
                    echo "<td>" . $row['applied_at'] . "</td>";
                    echo "<td>" . $row['full_name'] . "</td>"; // Display employee full name
                    echo "<td>" . $row['leave_subject'] . "</td>";
                    echo "<td>" . $row['leave_start_date'] . "</td>";
                    echo "<td>" . $row['leave_end_date'] . "</td>";
                    echo "<td>" . $row['leave_type'] . "</td>";
                    echo "<td>" . $row['leave_message'] . "</td>";
                    echo "<td>" . $row['status'] . "</td>"; //Display status
                    // Action buttons for accepting and rejecting leaves
                    echo "<td class='btn-group'>";
                    echo "<form action='' method='post'>";
                    echo "<input type='hidden' name='leave_id' value='" . $row['leave_id'] . "'>";
                    echo "<button type='submit' class='btn btn-success' name='approve'>Approve</button>";
                    echo "<button type='submit' class='btn btn-danger' name='reject'>Reject</button>";
                    echo "</form>";
                    echo "<a href='view_leave.php?leave_id=" . $row['leave_id'] . "' class='btn btn-primary'>View</a>";
                    echo "</td>";
                    echo "</tr>";
                }
                ?>
            </tbody>
        </table>
    </div>

    <!-- Include Bootstrap JS (if needed) -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</body>
</html>
