<?php
session_start();
require 'partials/_nav.php';
require 'partials/_dbconnect.php';

// Check if month and year are provided in the URL
if (isset($_GET['month']) && isset($_GET['year'])) {
    // Retrieve month and year from the URL
    $month = $_GET['month'];
    $year = $_GET['year'];

    // Format the selected month and year
    $selectedMonthName = date("F", mktime(0, 0, 0, $month, 1));
    $selectedYear = $year;
    

    // Display the heading
    echo "<h2>Salary Slips for $selectedMonthName $year</h2>";

    // Fetch salary details for the selected month and year with employee details
    $sql = "SELECT salary.*, Employees.first_name, Employees.last_name, Employees.designation
        FROM salary
        INNER JOIN Employees ON salary.emp_id = Employees.emp_id
        WHERE salary.month = '$month' AND salary.year = '$year'";
    $result = mysqli_query($conn, $sql);

    // Check if there are any salary slips for the selected month and year
    if (mysqli_num_rows($result) > 0) {
        // Display salary slips in a table
        echo '<table class="table">';
        echo '<thead>';
        echo '<tr>';
        echo '<th>Emp ID</th>';
        echo '<th>Full Name</th>';
        echo '<th>Designation</th>';
        echo '<th>Net Salary</th>';
        echo '<th>Salary Slip</th>';
        echo '</tr>';
        echo '</thead>';
        echo '<tbody>';

        // Loop through the salary details
        while ($row = mysqli_fetch_assoc($result)) {
            // Display employee details and a view button for each employee
            echo '<tr>';
            echo '<td>' . $row['emp_id'] . '</td>';
            echo '<td>' . $row['first_name'] . ' ' . $row['last_name'] . '</td>';
            echo '<td>' . $row['designation'] . '</td>';
            echo '<td>' . $row['net_salary'] . '</td>';
            // Assuming the view button redirects to a specific page where you can view the detailed salary slip
            echo '<td><a href="view_salary_slip.php?emp_id=' . $row['emp_id'] . '&month=' . $month . '&year=' . $year . '" class="btn btn-primary">View</a></td>';
            echo '</tr>';
        }

        echo '</tbody>';
        echo '</table>';
    } else {
        echo 'No salary slips found for the selected month and year.';
    }
} else {
    echo 'Month and year must be provided in the URL.';
}
?>
<!DOCTYPE html> 
<html> 
<head> 
    <title> Monthly slip </title> 
    <!-- Include your CSS stylesheets or Bootstrap CDN links here -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
</head> 
<body> 
    <!-- Include your JavaScript scripts or Bootstrap CDN links here -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</body> 
</html> 