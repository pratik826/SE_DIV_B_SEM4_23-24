<?php
// Check if a session is not already active before starting it
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

require_once 'partials/_dbconnect.php'; // Include your database connection script

// Check if the user is logged in
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
    $loggedin = true;
} else {
    $loggedin = false;
}

// Check if the user is an admin
$isadmin = false; // Assume user is not admin by default
if ($loggedin) {
    $emp_id = $_SESSION['emp_id'];
    $sql = "SELECT is_admin FROM Employees WHERE emp_id = '$emp_id'";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    if ($row && $row['is_admin'] == 1) {
        $isadmin = true; // User is admin
    }
}

$current_page = basename($_SERVER['PHP_SELF']);

echo '<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="/Project/loginsystem">Payroll Management System</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item ' . (($current_page === 'welcome.php') ? 'active' : '') . '">
        <a class="nav-link" href="/Project/loginsystem/welcome.php">Home ' . (($current_page === 'welcome.php') ? '<span class="sr-only">(current)</span>' : '') . '</a>
      </li>';

// Add signup option when the user is on the login page
if (!$loggedin && $current_page === 'login.php') {
    echo '<li class="nav-item ' . (($current_page === 'signup.php') ? 'active' : '') . '">
          <a class="nav-link" href="/Project/loginsystem/signup.php">Signup ' . (($current_page === 'signup.php') ? '<span class="sr-only">(current)</span>' : '') . '</a>
        </li>';
}

// Add login option when the user is not logged in
if (!$loggedin && $current_page !== 'login.php') {
    echo '<li class="nav-item ' . (($current_page === 'login.php') ? 'active' : '') . '">
          <a class="nav-link" href="/Project/loginsystem/login.php">Login ' . (($current_page === 'login.php') ? '<span class="sr-only">(current)</span>' : '') . '</a>
        </li>';
}

// Add options based on user's admin status
if ($loggedin) {
    if ($isadmin) {
        // Options for admin user
        // Dropdown menu for Employees option
        echo '<li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownEmployees" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
               Employees
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdownEmployees">
            <a class="dropdown-item" href="/Project/loginsystem/delete_employee.php">Delete Employee</a>
            <a class="dropdown-item" href="/Project/loginsystem/manage_employee.php">Manage Employee</a>
            </div>
            </li>';
        // Dropdown menu for Attendance and Leaves
        echo '<li class="nav-item dropdown ' . (($current_page === 'attendance.php' || $current_page === 'leaves.php') ? 'active' : '') . '">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownAttendance" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
               Attendance & Leaves
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdownAttendance">
            <a class="dropdown-item" href="/Project/loginsystem/view_attendance.php">View Attendance</a>
            <a class="dropdown-item" href="/Project/loginsystem/take_attendance.php">Take Attendance</a>
            <a class="dropdown-item" href="/Project/loginsystem/manage_leaves.php">Manage Leaves</a>
            </div>
            </li>';

            echo '<li class="nav-item dropdown ' . (($current_page === 'salary.php' || $current_page === 'salary_slips.php') ? 'active' : '') . '">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              Salary
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
              <a class="dropdown-item" href="/Project/loginsystem/salary.php">Salary Details ' . (($current_page === 'salary.php') ? '<span class="sr-only">(current)</span>' : '') . '</a>
              <a class="dropdown-item" href="/Project/loginsystem/salary_slips.php">Salary Slips ' . (($current_page === 'salary_slips.php') ? '<span class="sr-only">(current)</span>' : '') . '</a>
            </div>
          </li>';
    
        
    } else {
        // Options for non-admin user
        echo '<li class="nav-item">
            <a class="nav-link" href="/Project/loginsystem/profile.php">Profile</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/Project/loginsystem/user_attendance.php">Attendance</a>
          </li>';
        echo '<li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownLeaves" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              Leaves
              </a>
             <div class="dropdown-menu" aria-labelledby="navbarDropdownLeaves">
             <a class="dropdown-item" href="/Project/loginsystem/apply_leave.php">Apply for Leave</a>
             <a class="dropdown-item" href="/Project/loginsystem/your_leaves.php">Your Leaves</a>
             </div>
             </li>';

          echo '<li class="nav-item">
            <a class="nav-link" href="/Project/loginsystem/emp_salary.php">Salary</a>
          </li>';
          echo '<li class="nav-item">
            <a class="nav-link" href="/Project/loginsystem/investment.php">Investment Suggestions</a>
          </li>';
    }
}

// Add logout option when the user is logged in
if ($loggedin) {
    echo '<li class="nav-item ' . (($current_page === 'logout.php') ? 'active' : '') . '">
          <a class="nav-link" href="/Project/loginsystem/logout.php">Logout ' . (($current_page === 'logout.php') ? '<span class="sr-only">(current)</span>' : '') . '</a>
        </li>';
}

echo '</ul>
  </div>
</nav>';




