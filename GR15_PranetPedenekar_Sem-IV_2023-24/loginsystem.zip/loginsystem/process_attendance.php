<?php
// Start the session and include the navigation menu
session_start();
require 'partials/_nav.php';
require 'partials/_dbconnect.php';

$_SESSION['selected_date'] = $_POST['selected_date'];
// Display the title with the selected date
echo "<h2>Mark Attendance for {$_SESSION['selected_date']} </h2>";

// Check if the presence status for the selected date is already in the attendance table
$selected_date = $_SESSION['selected_date'];
$status_query = "SELECT emp_id, status FROM attendance WHERE date = '$selected_date'";
$status_result = mysqli_query($conn, $status_query);

// Create an associative array to store the presence status for each employee for the selected date
$status_array = array();
while ($row = mysqli_fetch_assoc($status_result)) {
    $status_array[$row['emp_id']] = $row['status'];
}

// Fetch non-admin employee information
$sql = "SELECT emp_id, CONCAT(first_name, ' ', last_name) AS full_name FROM Employees WHERE is_admin = 0";
$result = mysqli_query($conn, $sql);

// Check if query was successful
if ($result) {
    // Display table headers
    echo '<div class="container">
            <form action="submit_attendance.php" method="post">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Employee ID</th>
                                <th>Full Name</th>
                                <th>Presence Status</th>
                            </tr>
                        </thead>
                        <tbody>';

    // Display employee information in table rows
    while ($row = mysqli_fetch_assoc($result)) {
        echo '<tr>
                <td>' . $row['emp_id'] . '</td>
                <td>' . $row['full_name'] . '</td>
                <td>
                    <select name="attendance[' . $row['emp_id'] . ']">
                        <option value=""> Select </option>';
        // Check if presence status exists for the employee for the selected date
        if (isset($status_array[$row['emp_id']])) {
            $status = $status_array[$row['emp_id']];
            echo '<option value="' . $status . '" selected>' . ucfirst($status) . '</option>';
        } else {
            echo '<option value="present">Present</option>
                  <option value="absent">Absent</option>
                  <option value="onleave">On Leave</option>';
        }
        echo '</select>
                </td>
            </tr>';
    }

    // Close the table and form
    echo '</tbody>
          </table>
          <button type="submit" class="btn btn-primary">Submit Attendance</button>
        </form>
      </div>';
} else {
    // Handle query error
    echo 'Error: ' . mysqli_error($conn);
}

// Close the database connection
mysqli_close($conn);
?>

 
<!DOCTYPE html> 
<html> 
<head> 
    <title> Mark Attendance </title> 
    <!-- Include your CSS stylesheets or Bootstrap CDN links here -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
</head> 
<body> 
    <!-- Include your JavaScript scripts or Bootstrap CDN links here -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</body> 
</html> 
