<?php
session_start();
require 'partials/_dbconnect.php'; // Include your database connection script

// Fetch user data from the session
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    // Redirect the user to the login page if not logged in
    header("Location: login.php");
    exit;
}

$emp_id = $_SESSION['emp_id'];
$sql = "SELECT * FROM Employees WHERE emp_id = '$emp_id'";
$result = mysqli_query($conn, $sql);

// Check if user data was fetched successfully
if ($result && mysqli_num_rows($result) > 0) {
    // User data exists, fetch the data row
    $userData = mysqli_fetch_assoc($result);
} else {
    // User data not found, handle error (e.g., redirect to an error page)
    // For simplicity, let's redirect to the home page
    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
    <!-- Include your CSS stylesheets or Bootstrap CDN links here -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
</head>

<body>
    <?php require 'partials/_nav.php'; // Include your navigation menu ?>

    <div class="container">
        <h2>User Profile</h2>
        <p>Welcome, <?php echo $userData['username']; ?></p>
        <ul>
            <li>Full Name: <?php echo $userData['first_name'] . ' ' . $userData['last_name']; ?></li>
            <li>Employee ID: <?php echo $userData['emp_id']; ?></li>
            <li>Email: <?php echo $userData['email']; ?></li>
            <li>Gender: <?php echo $userData['gender']; ?></li>
            <li>Department: <?php echo $userData['department']; ?></li>
            <li>Designation: <?php echo $userData['designation']; ?></li>
            <li>Date of Birth: <?php echo $userData['dob']; ?></li>
            <li>Phone Number: <?php echo $userData['phone_number']; ?></li>
            <li>Bank Name: <?php echo $userData['bank_name']; ?></li>
            <li>Account Number: <?php echo $userData['bank_account']; ?></li>
            <li>IFSC Code: <?php echo $userData['ifsc_code']; ?></li>
            <li>PAN: <?php echo $userData['pan_number']; ?></li>
            <!-- Add more fields as needed -->
        </ul>
        <a href="edit_profile.php" class="btn btn-primary">Edit Profile</a>
    </div>

    <!-- Include your JavaScript scripts or Bootstrap CDN links here -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</body>

</html>



