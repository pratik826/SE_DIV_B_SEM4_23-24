<?php
session_start();
require 'partials/_nav.php';
require 'partials/_dbconnect.php'; // Include your database connection script

// Fetch non-admin employee information
$sql = "SELECT emp_id, CONCAT(first_name, ' ', last_name) AS full_name FROM Employees WHERE is_admin = 0";
$result = mysqli_query($conn, $sql);

// Check if query was successful
if ($result) {
    ?>

    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Salary Details</title>
        <!-- Include Bootstrap CSS -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    </head>
    <body>
        <div class="container mt-4">
            <h2>Salary Details</h2>
            <table class="table">
                <thead>
                    <tr>
                        <th>Employee ID</th>
                        <th>Full Name</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Display employee information in table rows
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo '<tr>
                                <td>' . $row['emp_id'] . '</td>
                                <td>' . $row['full_name'] . '</td>
                                <td><!-- Button for each employee -->
                                <a href="select_salary_month.php?emp_id=' . $row['emp_id'] . '" class="btn btn-primary">View</a>                                </td>
                            </tr>';
                    }
                    ?>
                </tbody>
            </table>
        </div>
        <!-- Include Bootstrap JS (if needed) -->
        <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
    </body>
    </html>

    <?php
} else {
    // Handle query error
    echo 'Error: ' . mysqli_error($conn);
}
?>

