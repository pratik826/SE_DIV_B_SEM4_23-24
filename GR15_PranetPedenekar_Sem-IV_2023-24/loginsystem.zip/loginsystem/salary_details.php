<?php
session_start();
require 'partials/_nav.php';
require 'partials/_dbconnect.php'; // Include your database connection script

// Check if emp_id, month, and year are provided in the URL
if (isset($_GET['emp_id']) && isset($_GET['month']) && isset($_GET['year'])) {
    // Get emp_id, month, and year from the URL
    $emp_id = $_GET['emp_id'];
    $month = $_GET['month'];
    $year = $_GET['year'];

    // Fetch employee data from the database
    $employeeSql = "SELECT * FROM Employees WHERE emp_id = '$emp_id'";
    $employeeResult = mysqli_query($conn, $employeeSql);

    // Check if employee data was fetched successfully
    if ($employeeResult && mysqli_num_rows($employeeResult) > 0) {
        // Employee data exists, fetch the data row
        $userData = mysqli_fetch_assoc($employeeResult);

        // Format the selected month and year
        $selectedMonthName = date("F", mktime(0, 0, 0, $month, 1));
        $selectedYear = $year;

        // Query to get the total number of present, absent, and on-leave days for the selected month and year
        $attendanceSql = "SELECT status FROM Attendance WHERE emp_id = '$emp_id' AND MONTH(date) = '$month' AND YEAR(date) = '$year'";
        $attendanceResult = mysqli_query($conn, $attendanceSql);

        // Initialize counters for present, absent, and on-leave days
        $presentCount = 0;
        $absentCount = 0;
        $leaveCount = 0;

        // Loop through the attendance records and count the status
        while ($attendanceData = mysqli_fetch_assoc($attendanceResult)) {
            if ($attendanceData['status'] == 'Present') {
                $presentCount++;
            } elseif ($attendanceData['status'] == 'Absent') {
                $absentCount++;
            } elseif ($attendanceData['status'] == 'On Leave') {
                $leaveCount++;
            }
        }

        // Calculate housing allowance amount
    $housingAllowanceAmount = $userData['basic_salary'] * ($userData['ha_rate'] / 100);

    // Calculate tax amount
    $taxAmount = $userData['basic_salary'] * ($userData['tax_rate'] / 100);

    // Calculate PF amount
    $pfAmount = $userData['basic_salary'] * ($userData['pf_rate'] / 100);

    // Calculate deduction per absence (you can define this value according to your business logic)
    $deductionPerAbsence = 100; // Example: $100 deduction per absence

    // Calculate deduction amount based on absent count
    $absenceDeduction = $absentCount * $deductionPerAbsence;

    // Calculate total earnings
    $totalEarnings = $userData['basic_salary'] + $housingAllowanceAmount;

    // Calculate total deductions
    $totalDeductions = $taxAmount + $pfAmount + $absenceDeduction;

    // Calculate net salary
    $netSalary = $totalEarnings - $totalDeductions;

        // Display employee information
        ?>
        
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Employee Salary Details</title>
            <!-- Include Bootstrap CSS -->
            <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
        </head>
        <body>
            <div class="container mt-4">
                <h2>Salary details of <?php echo $userData['first_name'] . ' ' . $userData['last_name']; ?> for <?php echo $selectedMonthName; ?> <?php echo $selectedYear; ?></h2>
                <div>
                    <p><strong>Employee ID:</strong> <?php echo $userData['emp_id']; ?></p>
                    <p><strong>Full Name:</strong> <?php echo $userData['first_name'] . ' ' . $userData['last_name']; ?></p>
                    <p><strong>Department:</strong> <?php echo $userData['department']; ?></p>
                    <p><strong>Designation:</strong> <?php echo $userData['designation']; ?></p>
                    <p><strong>Basic Salary:</strong> <?php echo $userData['basic_salary']; ?></p>
                    <p><strong>Tax Rate:</strong> <?php echo $userData['tax_rate']; ?>%</p>
                    <p><strong>PF Rate:</strong> <?php echo $userData['pf_rate']; ?>%</p>
                    <p><strong>Housing Allowance Rate:</strong> <?php echo $userData['ha_rate']; ?>%</p>
                    <!-- Add more fields as needed -->

                    <!-- Display total counts of present, absent, and on-leave days -->
                    <p><strong>Total Present:</strong> <?php echo $presentCount; ?></p>
                    <p><strong>Total Absent:</strong> <?php echo $absentCount; ?></p>
                    <p><strong>Total On Leave:</strong> <?php echo $leaveCount; ?></p>

                    <p><strong>Housing Allowance Amount:</strong> <?php echo $housingAllowanceAmount; ?></p>
                    <p><strong>Tax Amount:</strong> <?php echo $taxAmount; ?></p>
                    <p><strong>PF Amount:</strong> <?php echo $pfAmount; ?></p>  
                    <p><strong>Deduction Amount for Absences:</strong> <?php echo $absenceDeduction; ?></p>                  
                    <p><strong>Earnings (Basic Salary + Housing Allowance):</strong> <?php echo $totalEarnings; ?></p>
                    <p><strong>Total Deductions (Tax + PF + Absence Deduction):</strong> <?php echo $totalDeductions; ?></p>

                    <!-- Display net salary -->
                    <p><strong>Net Salary:</strong> <?php echo $netSalary; ?></p>                    
                </div>
                <!-- Form to submit salary details -->
                <form action="insert_salary_details.php" method="post">
                   <input type="hidden" name="emp_id" value="<?php echo $userData['emp_id']; ?>">
                   <input type="hidden" name="month" value="<?php echo $month; ?>">
                   <input type="hidden" name="year" value="<?php echo $year; ?>">
                   <input type="hidden" name="housing_allowance" value="<?php echo $housingAllowanceAmount; ?>">
                   <input type="hidden" name="tax_amount" value="<?php echo $taxAmount; ?>">
                   <input type="hidden" name="pf_amount" value="<?php echo $pfAmount; ?>">
                   <input type="hidden" name="absence_deduction" value="<?php echo $absenceDeduction; ?>">
                   <input type="hidden" name="earnings" value="<?php echo $totalEarnings; ?>">
                   <input type="hidden" name="total_deduction" value="<?php echo $totalDeductions; ?>">
                   <input type="hidden" name="net_salary" value="<?php echo $netSalary; ?>">
                   <input type="submit" class="btn btn-primary" value="Submit to generate Salary slip">
                </form>
            </div>

            <!-- Include Bootstrap JS (if needed) -->
            <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
            <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
            <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
        </body>
        </html>

        <?php
    } else {
        // Employee data not found, handle error (e.g., redirect to an error page)
        // For simplicity, let's redirect to the home page
        header("Location: index.php");
        exit;
    }
} else {
    // Redirect to an error page or handle the case where emp_id is not provided in the URL
    // For simplicity, let's redirect to the home page
    header("Location: index.php");
    exit;
}
?>
