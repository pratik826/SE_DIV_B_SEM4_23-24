<?php
session_start();
require 'partials/_nav.php';
require 'partials/_dbconnect.php'; // Include your database connection script

// Check if emp_id is provided in the URL
if (isset($_GET['emp_id'])) {
    // Get the emp_id from the URL
    $emp_id = $_GET['emp_id'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Select Salary Month</title>
    <!-- Include Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-4">
        <h2>Select Month and Year</h2>
        <form action="salary_details.php" method="get">
            <input type="hidden" name="emp_id" value="<?php echo $emp_id; ?>">
            <div class="form-row">
                <div class="form-group col-md-6">
                    <label for="month">Select Month:</label>
                    <select class="form-control" id="month" name="month">
                        <?php
                        // Loop through the months (1 to 12)
                        for ($i = 1; $i <= 12; $i++) {
                            // Format the month number as two digits (e.g., 01 for January)
                            $monthNumber = sprintf("%02d", $i);
                            // Use mktime() to get the month name based on the number
                            $monthName = date("F", mktime(0, 0, 0, $i, 1));
                            // Output an <option> tag for each month
                            echo "<option value='$monthNumber'>$monthName</option>";
                        }
                        ?>
                    </select>
                </div>
                <div class="form-group col-md-6">
                    <label for="year">Select Year:</label>
                    <select class="form-control" id="year" name="year">
                        <?php
                        // Define the range of years (e.g., from 2020 to 2030)
                        $startYear = 2020;
                        $endYear = 2030;
                        // Loop through the range of years
                        for ($year = $startYear; $year <= $endYear; $year++) {
                            // Output an <option> tag for each year
                            echo "<option value='$year'>$year</option>";
                        }
                        ?>
                    </select>
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>

    <!-- Include Bootstrap JS (if needed) -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</body>
</html>

<?php
} else {
    // Redirect to an error page or handle the case where emp_id is not provided in the URL
    // For simplicity, let's redirect to the home page
    header("Location: index.php");
    exit;
}
?>
