<?php
// Start the session and include the navigation menu
session_start();
require 'partials/_nav.php';
require 'partials/_dbconnect.php';

$selected_date = $_SESSION['selected_date'];

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    

    // Fetch attendance data from the form
    $attendance = $_POST['attendance'];

    // Prepare and execute SQL query to insert attendance data into the database
    $stmt = $conn->prepare("INSERT INTO attendance (emp_id, date, status) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $emp_id, $selected_date, $presenty_status);

    // Loop through attendance data and insert into the database
    foreach ($attendance as $emp_id => $presenty_status) {
        $stmt->execute();
    }

    // Close the prepared statement
    $stmt->close();

    // Display success alert
    echo '<script>alert("Attendance submitted successfully!");</script>';
}

// Close the database connection
mysqli_close($conn);
?>

<!DOCTYPE html> 
<html> 
<head> 
    <title> Mark Attendance </title> 
    <!-- Include your CSS stylesheets or Bootstrap CDN links here -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
</head> 
<body> 
    <!-- Include your JavaScript scripts or Bootstrap CDN links here -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</body> 
</html> 