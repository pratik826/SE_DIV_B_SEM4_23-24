<?php
session_start();
require 'partials/_dbconnect.php'; // Include your database connection script

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $emp_id = $_POST['emp_id'];
    $department = $_POST['department'];
    $designation = $_POST['designation'];
    $basic_salary = $_POST['basic_salary'];
    $tax_rate = $_POST['tax_rate'];
    $pf_rate = $_POST['pf_rate'];
    $ha_rate = $_POST['ha_rate'];
    // Retrieve other form data as needed

    // Update employee record in the database
    $sql = "UPDATE Employees SET department = '$department', designation = '$designation', basic_salary = '$basic_salary', tax_rate = '$tax_rate', pf_rate = '$pf_rate', ha_rate = '$ha_rate' WHERE emp_id = '$emp_id'"; // Assuming $emp_id is set somewhere
    $result = mysqli_query($conn, $sql);

    if ($result) {
        // Redirect to a success page or display a success message
        echo "Updated Sucessfully";
        exit();
    } else {
        // Redirect to an error page or display an error message
        header("Location: error.php");
        exit();
    }
} else {
    // Redirect to an error page or display an error message
    header("Location: error.php");
    exit();
}
?>
