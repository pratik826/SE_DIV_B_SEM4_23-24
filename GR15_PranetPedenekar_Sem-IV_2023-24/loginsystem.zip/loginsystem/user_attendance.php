<?php
session_start();
require 'partials/_nav.php';
require 'partials/_dbconnect.php';

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the selected year
    $selectedYear = $_POST['year'];

    // Fetch the employee ID of the logged-in user
    $emp_id = $_SESSION['emp_id'];

    // Fetch monthly attendance data for the selected year and the logged-in user
    $monthlyAttendance = array();
    for ($month = 1; $month <= 12; $month++) {
        // Query to get total present count for each month for the logged-in user
        $sql = "SELECT COUNT(*) as total_present FROM attendance WHERE emp_id = $emp_id AND YEAR(date) = $selectedYear AND MONTH(date) = $month AND status = 'present'";
        $result = mysqli_query($conn, $sql);
        $row = mysqli_fetch_assoc($result);
        $monthlyAttendance[$month] = $row['total_present'];
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Monthly Attendance</title>
    <!-- Include Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-4">
        <!-- Form to select the year -->
        <h2>Select Year to View Monthly Attendance</h2>
        <form action="" method="POST">
            <div class="form-group">
                <label for="year">Select Year:</label>
                <select class="form-control" name="year" id="year" required>
                    <?php
                    // Generate options for the year dropdown (from current year to next 10 years)
                    $currentYear = date("Y");
                    for ($i = $currentYear; $i <= $currentYear + 10; $i++) {
                        echo "<option value='$i'>$i</option>";
                    }
                    ?>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">View Attendance</button>
        </form>
    </div>

    <!-- Display monthly attendance data -->
    <?php if ($_SERVER["REQUEST_METHOD"] == "POST") : ?>
        <div class="container mt-4">
            <h2>Monthly Attendance for <?php echo $selectedYear; ?></h2>
            <table class="table">
                <thead>
                    <tr>
                        <th>Month</th>
                        <th>Total Present</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $months = [
                        1 => "January", 2 => "February", 3 => "March", 4 => "April", 5 => "May", 6 => "June",
                        7 => "July", 8 => "August", 9 => "September", 10 => "October", 11 => "November", 12 => "December"
                    ];
                    foreach ($months as $monthNum => $monthName) {
                        echo "<tr>
                                <td>$monthName</td>
                                <td>{$monthlyAttendance[$monthNum]}</td>
                              </tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>

    <!-- Include Bootstrap JS (if needed) -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</body>
</html>


