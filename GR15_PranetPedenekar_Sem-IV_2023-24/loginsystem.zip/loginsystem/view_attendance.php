<?php 
// Include navigation menu and database connection
require 'partials/_nav.php';
require 'partials/_dbconnect.php';

// Query to fetch non-admin employee names
$sql = "SELECT CONCAT(first_name, ' ', last_name) AS full_name FROM Employees WHERE is_admin = 0";
$result = mysqli_query($conn, $sql);

// Check if query was successful
if ($result) {
    $employee_names = array(); // Initialize an array to store employee names

    // Fetch employee names from the result set
    while ($row = mysqli_fetch_assoc($result)) {
        $employee_names[] = $row['full_name'];
    }
} else {
    // Handle query error
    echo 'Error: ' . mysqli_error($conn);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Attendance</title>
    <!-- Include Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-4">
        <h2>Select Date to View Attendance</h2>
        <form action="view_attendance_bydate.php" method="POST">
            <div class="form-group">
                <label for="attendance_date">Select Date:</label>
                <input type="date" id="attendance_date" name="attendance_date" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary">View Attendance</button>
        </form>
    </div>

    <div class="container mt-4">
    <h2>Select Employee and Month to View Monthly Attendance</h2>
    <form action="view_attendance_monthly.php" method="POST">
        <div class="form-group">
            <label for="employee_name">Employee Name:</label>
            <select id="employee_name" name="employee_name" class="form-control" required>
                <option value="">Select Employee</option>
                <?php
                // Populate dropdown with non-admin employee names
                foreach ($employee_names as $name) {
                    echo "<option value='$name'>$name</option>";
                }
                ?>
            </select>
        </div>
        <div class="form-group">
            <label for="month">Month:</label>
            <input type="month" id="month" name="month" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-primary">View Monthly Attendance</button>
    </form>
</div>

    <!-- Include Bootstrap JS (if needed) -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</body>
</html>




