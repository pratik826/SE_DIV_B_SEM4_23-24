<?php
session_start();
require 'partials/_nav.php';
require 'partials/_dbconnect.php';

// Retrieve the selected date from the form
$attendance_date = $_POST['attendance_date'];

// Convert the selected date format to match the database format (dd-mm-yyyy to yyyy-mm-dd)
$selected_date = date("Y-m-d", strtotime($attendance_date));

// Fetch attendance data for the selected date along with employee names
$sql = "SELECT a.emp_id, e.first_name, e.last_name, a.status 
        FROM attendance a 
        INNER JOIN Employees e ON a.emp_id = e.emp_id 
        WHERE a.date = '$selected_date'";
$result = mysqli_query($conn, $sql);

if ($result) {
    // Display attendance data
    echo "<div class='container'>";
    echo "<h2>Attendance for $selected_date</h2>";
    echo "<table class='table table-striped'>";
    echo "<thead><tr><th>Employee ID</th><th>Full Name</th><th>Status</th></tr></thead>";
    echo "<tbody>";
    while ($row = mysqli_fetch_assoc($result)) {
        $full_name = $row['first_name'] . ' ' . $row['last_name'];
        echo "<tr><td>{$row['emp_id']}</td><td>$full_name</td><td>{$row['status']}</td></tr>";
    }
    echo "</tbody></table>";
    echo "</div>";
} else {
    // Handle query error
    echo 'Error: ' . mysqli_error($conn);
}

// Close the database connection
mysqli_close($conn);
?>

<!DOCTYPE html> 
<html> 
<head> 
    <title> Mark Attendance </title> 
    <!-- Include your CSS stylesheets or Bootstrap CDN links here -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
</head> 
<body> 
    <!-- Include your JavaScript scripts or Bootstrap CDN links here -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</body> 
</html> 