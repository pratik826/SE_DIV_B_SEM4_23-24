<?php
// Include navigation menu and database connection
require 'partials/_nav.php';
require 'partials/_dbconnect.php';

// Check if employee name and month are provided in the request
if(isset($_POST['employee_name']) && isset($_POST['month'])) {
    // Get employee name and month from the request
    $employee_name = $_POST['employee_name'];
    $month = $_POST['month'];

    // Extract year and month from the selected month value (format: YYYY-MM)
    $year = date('Y', strtotime($month));
    $month_number = date('m', strtotime($month));

    // Query to fetch attendance data for the selected employee and month
    $sql = "SELECT * FROM attendance WHERE emp_id = (
                SELECT emp_id FROM Employees WHERE CONCAT(first_name, ' ', last_name) = '$employee_name'
            ) AND YEAR(date) = $year AND MONTH(date) = $month_number";
    $result = mysqli_query($conn, $sql);

    // Check if query was successful
    if ($result) {
        // Initialize counters for present and absent days
        $present_count = 0;
        $absent_count = 0;
        $leave_count = 0;

        // Display attendance data in a table
        echo "<div class='container mt-4'>";
        echo "<h2>Monthly Attendance for $employee_name - $month</h2>";
        echo "<table class='table'>
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>";

        // Fetch and display attendance records
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>
                    <td>{$row['date']}</td>
                    <td>{$row['status']}</td>
                  </tr>";

            // Update counters based on status
            if ($row['status'] == 'Present') {
                $present_count++;
            } elseif ($row['status'] == 'Absent') {
                $absent_count++;
            } elseif ($row['status'] == 'On Leave') {
                $leave_count++;
            }
        }

        echo "</tbody></table>";

        // Display total present and absent counts
        echo "<p>Total Present: $present_count</p>";
        echo "<p>Total Absent: $absent_count</p>";
        echo "<p>Total Leaves: $leave_count</p>";

        echo "</div>";
    } else {
        // Handle query error
        echo 'Error: ' . mysqli_error($conn);
    }
} else {
    // Display error if employee name and month are not provided
    echo "Error: Employee name and month are required.";
}
?>


<!DOCTYPE html> 
<html> 
<head> 
    <title> Mark Attendance </title> 
    <!-- Include your CSS stylesheets or Bootstrap CDN links here -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
</head> 
<body> 
    <!-- Include your JavaScript scripts or Bootstrap CDN links here -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</body> 
</html> 