<?php
session_start();
require 'partials/_nav.php';
require 'partials/_dbconnect.php';

// Check if the employee is logged in
if (!isset($_SESSION['emp_id'])) {
    // Redirect to login page if not logged in
    header("Location: login.php");
    exit();
}

// Check if leave_id is provided in the URL
if (!isset($_GET['leave_id']) || empty($_GET['leave_id'])) {
    // Redirect to some error page if leave_id is missing
    header("Location: error.php");
    exit();
}

// Retrieve leave ID from URL parameter
$leaveId = $_GET['leave_id'];

// Query to fetch leave details based on the provided leave ID
$sql = "SELECT * FROM leaves WHERE leave_id = '$leaveId'";
$result = mysqli_query($conn, $sql);

// Check if leave record exists
if (mysqli_num_rows($result) == 0) {
    // Redirect to error page if leave record does not exist
    header("Location: error.php");
    exit();
}

// Fetch leave details from the result
$row = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Leave</title>
    <!-- Include Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-4">
        <h2>View Leave</h2>
        <div class="row">
            <div class="col-md-6">
                <p><strong>Employee ID:</strong> <?php echo $row['emp_id']; ?></p>
                <p><strong>Leave Subject:</strong> <?php echo $row['leave_subject']; ?></p>
                <p><strong>Leave Start Date:</strong> <?php echo $row['leave_start_date']; ?></p>
                <p><strong>Leave End Date:</strong> <?php echo $row['leave_end_date']; ?></p>
                <p><strong>Leave Type:</strong> <?php echo $row['leave_type']; ?></p>
                <p><strong>Leave Message:</strong> <?php echo $row['leave_message']; ?></p>
                <p><strong>Status:</strong> <?php echo $row['status']; ?></p>
            </div>
        </div>
    </div>

    <!-- Include Bootstrap JS (if needed) -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</body>
</html>
