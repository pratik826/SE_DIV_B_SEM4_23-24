<?php
session_start();
require 'partials/_nav.php';
require 'partials/_dbconnect.php';

// Check if emp_id, month, and year are provided in the URL
if (isset($_GET['emp_id']) && isset($_GET['month']) && isset($_GET['year'])) {
    // Retrieve emp_id, month, and year from the URL
    $emp_id = $_GET['emp_id'];
    $month = $_GET['month'];
    $year = $_GET['year'];

    // Fetch employee details from the Employees table
    $employeeSql = "SELECT * FROM Employees WHERE emp_id = '$emp_id'";
    $employeeResult = mysqli_query($conn, $employeeSql);
    $employeeData = mysqli_fetch_assoc($employeeResult);

    // Fetch salary details from the Salary table
    $salarySql = "SELECT * FROM Salary WHERE emp_id = '$emp_id' AND month = '$month' AND year = '$year'";
    $salaryResult = mysqli_query($conn, $salarySql);
    $salaryData = mysqli_fetch_assoc($salaryResult);

    // Fetch attendance details from the Attendance table for the selected month and year
    $attendanceSql = "SELECT status FROM Attendance WHERE emp_id = '$emp_id' AND MONTH(date) = '$month' AND YEAR(date) = '$year'";
    $attendanceResult = mysqli_query($conn, $attendanceSql);

    // Initialize counters for present, absent, and on-leave days
    $presentCount = 0;
    $absentCount = 0;
    $leaveCount = 0;

    // Loop through the attendance records and count the status
    while ($attendanceData = mysqli_fetch_assoc($attendanceResult)) {
        if ($attendanceData['status'] == 'Present') {
            $presentCount++;
        } elseif ($attendanceData['status'] == 'Absent') {
            $absentCount++;
        } elseif ($attendanceData['status'] == 'On Leave') {
            $leaveCount++;
        }
    }
    ?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Salary Slip</title>
        <!-- Include Bootstrap CSS -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
        <!-- Include your custom CSS for styling -->
        <style>
            .details-container {
                display: flex;
                justify-content: space-between;
                flex-wrap: wrap;
            }

            .details-column {
                flex: 1 1 30%;
                margin-right: 20px;
            }
        </style>
    </head>
    <body id="target">
        <div class="container mt-4">
            <div class="details-container">
                <div class="details-column">
                    <h2>Employee Details</h2>
                    <p><strong>Emp ID:</strong> <?php echo $employeeData['emp_id']; ?></p>
                    <p><strong>Full Name:</strong> <?php echo $employeeData['first_name'] . ' ' . $employeeData['last_name']; ?></p>
                    <p><strong>Department:</strong> <?php echo $employeeData['department']; ?></p>
                    <p><strong>Designation:</strong> <?php echo $employeeData['designation']; ?></p>
                    <p><strong>Phone No:</strong> <?php echo $employeeData['phone_number']; ?></p>
                </div>

                <div class="details-column">
                    <h2>Bank Details</h2>
                    <p><strong>Bank Name:</strong> <?php echo $employeeData['bank_name']; ?></p>
                    <p><strong>Bank Account No:</strong> <?php echo $employeeData['bank_account']; ?></p>
                    <p><strong>IFSC Code:</strong> <?php echo $employeeData['ifsc_code']; ?></p>
                    <p><strong>PAN Number:</strong> <?php echo $employeeData['pan_number']; ?></p>
                </div>

                <div class="details-column">
                    <h2>Attendance for <?php echo $month . ' ' . $year; ?></h2>
                    <p><strong>Total Present:</strong> <?php echo $presentCount; ?></p>
                    <p><strong>Total Absent:</strong> <?php echo $absentCount; ?></p>
                    <p><strong>Total On Leave:</strong> <?php echo $leaveCount; ?></p>
                </div>
            </div>
            <div class="details-container">
                <div class="details-column">
                    <h4>Earnings</h4>
                    <p><strong>Basic Salary:</strong> <?php echo $employeeData['basic_salary']; ?></p>
                    <p><strong>Housing Allowance:</strong> <?php echo $salaryData['ha_amount']; ?></p>
                    <p><strong>Total Earnings:</strong> <?php echo $salaryData['earnings']; ?></p>
                </div>
                <div class="details-column">
                    <h4>Deductions</h4>
                    <p><strong>Tax Amount:</strong> <?php echo $salaryData['tax_amt']; ?></p>
                    <p><strong>PF Amount:</strong> <?php echo $salaryData['pf_amt']; ?></p>
                    <p><strong>Absence Deduction:</strong> <?php echo $salaryData['absence_deduction']; ?></p>
                    <p><strong>Total Deduction:</strong> <?php echo $salaryData['total_deductions']; ?></p>
                </div>
                <div class="details-column">
                    <h4>Net Salary</h4>
                    <p><strong>Net Salary:</strong> <?php echo $salaryData['net_salary']; ?></p>
                </div>
                <form id="pdfForm" method="post" action="generate_pdf.php" style="display: none;">
                <input type="hidden" name="emp_id" value="<?php echo $emp_id; ?>">
                <input type="hidden" name="month" value="<?php echo $month; ?>">
                <input type="hidden" name="year" value="<?php echo $year; ?>">
                <input type="hidden" name="first_name" value="<?php echo $employeeData['first_name']; ?>">
                <input type="hidden" name="last_name" value="<?php echo $employeeData['last_name']; ?>">
                <input type="hidden" name="department" value="<?php echo $employeeData['department']; ?>">
                <input type="hidden" name="designation" value="<?php echo $employeeData['designation']; ?>">
                <input type="hidden" name="phone_number" value="<?php echo $employeeData['phone_number']; ?>">
                <input type="hidden" name="bank_name" value="<?php echo $employeeData['bank_name']; ?>">
                <input type="hidden" name="bank_account" value="<?php echo $employeeData['bank_account']; ?>">
                <input type="hidden" name="ifsc_code" value="<?php echo $employeeData['ifsc_code']; ?>">
                <input type="hidden" name="pan_number" value="<?php echo $employeeData['pan_number']; ?>">
                <input type="hidden" name="presentCount" value="<?php echo $presentCount; ?>">
                <input type="hidden" name="absentCount" value="<?php echo $absentCount; ?>">
                <input type="hidden" name="leaveCount" value="<?php echo $leaveCount; ?>">
                <input type="hidden" name="basic_salary" value="<?php echo $employeeData['basic_salary']; ?>">
                <input type="hidden" name="ha_amount" value="<?php echo $salaryData['ha_amount']; ?>">
                <input type="hidden" name="earnings" value="<?php echo $salaryData['earnings']; ?>">
                <input type="hidden" name="tax_amt" value="<?php echo $salaryData['tax_amt']; ?>">
                <input type="hidden" name="pf_amt" value="<?php echo $salaryData['pf_amt']; ?>">
                <input type="hidden" name="absence_deduction" value="<?php echo $salaryData['absence_deduction']; ?>">
                <input type="hidden" name="total_deductions" value="<?php echo $salaryData['total_deductions']; ?>">
                <input type="hidden" name="net_salary" value="<?php echo $salaryData['net_salary']; ?>">
                </form>

                <!-- "Generate pdf" button with onclick event to submit form -->
                <button id="cmd" onclick="document.getElementById('pdfForm').submit()">Download pdf</button>
            </div>
        </div>
       

     <!-- Include your JavaScript scripts or Bootstrap CDN links here -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    

 

    </body>
   
</html>

<?php
} else {
    // Redirect or display an error message if emp_id, month, or year is not provided
    echo "Employee ID, month, and year must be provided in the URL.";
}
?>  