<?php
session_start();
require 'partials/_nav.php'; 

// Check if the user is logged in
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("location: login.php");
    exit;
}

// Include database connection
require 'partials/_dbconnect.php';

// Retrieve emp_id from session
$emp_id = $_SESSION['emp_id'];

// Fetch user information from the database
$sql = "SELECT * FROM Employees WHERE emp_id='$emp_id'";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);

// Display user information
echo "<h1>Welcome " . $row['first_name'] . " " . $row['last_name'] . "</h1>";
echo "<p>Employee ID : " . $row['emp_id'] . "</p>";

// Add more information as needed
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome</title>
    <!-- Include Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
</head>
<body>
    

    <div class="container my-4">
        <!-- Your content here -->
    </div>

    <!-- Include Bootstrap JS (if needed) -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</body>
</html>

