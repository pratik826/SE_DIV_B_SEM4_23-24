<?php
session_start();
require 'partials/_nav.php';
require 'partials/_dbconnect.php';

// Check if the employee is logged in
if (!isset($_SESSION['emp_id'])) {
    // Redirect to login page if not logged in
    header("Location: login.php");
    exit();
}

// Retrieve the logged-in employee's emp_id
$empId = $_SESSION['emp_id'];

// Retrieve the leave records for the logged-in employee from the database
$sql = "SELECT * FROM leaves WHERE emp_id = '$empId'";
$result = mysqli_query($conn, $sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Leaves</title>
    <!-- Include Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-4">
        <h2>Your Leaves</h2>
        <table class="table">
            <thead>
                <tr>
                    <th>Leave ID</th>
                    <th>Date of Application</th>
                    <th>Leave Subject</th>
                    <th>Leave Start Date</th>
                    <th>Leave End Date</th>
                    <th>Leave Type</th>
                    <th>Leave Message</th>
                    <th>Status</th>
                    <th>Action</th> <!-- New column for action -->

                </tr>
            </thead>
            <tbody>
                <?php
                // Loop through each row of leave records
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>";
                    echo "<td>" . $row['leave_id'] . "</td>";
                    echo "<td>" . $row['applied_at'] . "</td>";
                    echo "<td>" . $row['leave_subject'] . "</td>";
                    echo "<td>" . $row['leave_start_date'] . "</td>";
                    echo "<td>" . $row['leave_end_date'] . "</td>";
                    echo "<td>" . $row['leave_type'] . "</td>";
                    echo "<td>" . $row['leave_message'] . "</td>";
                    echo "<td>" . $row['status'] . "</td>";
                    echo "<td><a href='view_leave.php?leave_id=" . $row['leave_id'] . "' class='btn btn-primary'>View</a></td>"; // View button
                    echo "</tr>";
                }
                ?>
            </tbody>
        </table>
    </div>

    <!-- Include Bootstrap JS (if needed) -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</body>
</html>
